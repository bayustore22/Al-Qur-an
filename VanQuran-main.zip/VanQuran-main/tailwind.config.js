module.exports = {
  content: ['*.html', './dist/**/*.{js, css}'],
  theme: {
    extend: {},
  },
  plugins: [],
}
